/*
Kako bi se modificirao „Hello World!“ primjer da
samo procesori parnog ranga ispisuju navedenu
informaciju?
*/

#include <iostream>
#include <mpi.h>


int main (int argc, char* argv[]) {

    using namespace std;
    int rang, velicina;

    MPI::Init(argc, argv);
    rang = MPI::COMM_WORLD.Get_rank();
    velicina = MPI::COMM_WORLD.Get_size();
    
 if(rang%2 == 0){
   cout << "\nProcesor ranga " << rang << " od " << velicina << ": Hello World" << endl;
}

    MPI::Finalize();
    return 0;

}





