/* 
Napišite program koji će ispisati proizvoljnu
poruku na monitor onoliko puta koliki je rang
procesa koji ispisuje poruku. Pokrenite dobiveni
program na 1, 2, 7 i 11 procesora. 
*/

#include <iostream>
#include <mpi.h>

using namespace std;

int main (int argc, char* argv[]) {

    int rang, velicina;

    MPI::Init(argc, argv);
    rang = MPI::COMM_WORLD.Get_rank();

 for(int i = 0; i<rang;i++){
    cout << "Rang " << rang << ": Hello World!\n\n";
}

    MPI::Finalize();
    return 0;

}


