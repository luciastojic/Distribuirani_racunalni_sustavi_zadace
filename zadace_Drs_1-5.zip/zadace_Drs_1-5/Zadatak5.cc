/*                                                                                                                                                                                                /*
Generirati proizvoljnu matricu. Distribuirati pojedni redak
pojedinom računalu(procesu). Formirati donju trokutastu matricu
sa ispisom naziva računala(procesa) koji je ispisao pojedini redak.
Program napisati korištenjem C++ funkcija.
*/
#include <iostream>
#include <mpi.h>
using namespace std;
int main (int argc, char* argv[]) {
        int rang;
        int velicina;
		
        MPI::Request zahtjev;
        MPI::Status status;

        MPI::Init(argc, argv); 
        rang = MPI::COMM_WORLD.Get_rank(); 
        velicina = MPI::COMM_WORLD.Get_size();
        double a[100][100], b[100];
	
        if( rang == 0 ) {
                for (int i=0;i<velicina;i++){
                        for (int j=0;j<velicina;j++){
                                a[i][j]=i*1;
                        }

                }
        }
     
        MPI::COMM_WORLD.Scatter(a, 100, MPI::DOUBLE, b,100,MPI::DOUBLE,0); 
        if(rang!=0){
        	
                MPI::COMM_WORLD.Recv(a,1,MPI::DOUBLE,rang-1, 25);
        }
        cout<<"Proces "<<rang<<": ";
        for (int i=0;i<=rang;i++){
                cout<<b[i]<<" ";
        }
        cout<<endl;

        if(rang<velicina-1){
       
                MPI::COMM_WORLD.Send(a,1,MPI::DOUBLE,rang+1,25); 
        }
        MPI::Finalize(); 
        return 0;
}
