/*
Napisati program koji izračunava zbroj prilagodjenih prefiksa dan u nastavku za 4 različita niza i nakon toga ih sve zbrojiti.
Upotrijebiti OpenMP direktive za paralelno izvršavanje

A(1) = A(1)
A(2) = A(2) + A(1)
A(i) = A(i-2) + A(i-1)
*/

#include <iostream>
#include <vector>
#include <omp.h>
using namespace std;

#define N 10

int main() {
    vector<int> x(N), y(N), z(N), c(N), zb(N);
    int sum = 0;

    #pragma omp parallel for
    for (int i = 0; i < N; i++) {
        x[i] = i + 1;
        y[i] = i * 2;
        z[i] = i + 2;
        c[i] = i * 3;
    }

    #pragma omp parallel for
    for (int i = 0; i < N; i++) {
        if (i == 1) {
            x[i] += x[0];
            y[i] += y[0];
            z[i] += z[0];
            c[i] += c[0];
        } 
        if (i > 1) {
            x[i] = x[i - 2] + x[i - 1];
            y[i] = y[i - 2] + y[i - 1];
            z[i] = z[i - 2] + z[i - 1];
            c[i] = c[i - 2] + c[i - 1];
        }
        zb[i] = x[i] + y[i] + z[i] + c[i];
    }

    for (int i = 0; i < N; i++) {
        sum += zb[i];
    }

    cout << "Ukupna suma 4 niza je: " << sum << endl;

    return 0;
}
