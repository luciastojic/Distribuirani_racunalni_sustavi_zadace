 /* 
 Uporabom MPI-a izraditi simulaciju raspodijeljenog problema n
filozofa. Pri svakoj promjeni program mora vizualno prikazati za
sve filozofe što oni rade. Npr. kada filozof 4 ide jesti, tada treba
ispis izgledati otprilike ovako: "Stanje filozofa: X o O X o" (X-jede,
O-razmišlja, o-čeka na vilice).
Problem pet filozofa. Filozofi obavljaju samo dvije različite
aktivnosti: misle ili jedu. To rade na poseban način. Na jednom
okruglom stolu nalazi se pet tanjura te pet štapića (između
svaka dva tanjura po jedan). Filozof prilazi stolu, uzima lijevi
štapić, pa desni te jede. Zatim vraća štapiće na stol i odlazi
misliti.
Program napisati korištenjem C++ funkcija.
 */


#include <iostream>
#include <thread>
#include <mutex>
#include <vector>
#include <memory>
#include <mpi.h>
using namespace std;

vector<mutex> forks;
vector<string> states;

void philosopher(int id, unique_ptr<mutex[]> &forks, vector<string> &states)
{
    int count = 0;
    
    while(count < 4)
    {
    	//postavljanje trenutnog stanja na O tj 'misli' i ispis
        states[id] = "O";
        cout << "Stanje filozofa " << id << ": ";
        for (int i = 0; i < states.size(); i++)
        {
            cout << states[i] << " ";
        }
        cout << endl;
        this_thread::sleep_for(chrono::seconds(1));
        //zakljucavanje vilice sa obje strane kako bi mogao jesti
        forks[id].lock();
        forks[(id + 1) % states.size()].lock();

        //ako su zakljucavanja uspjesna, postavi stanje filozofa na "X" (jede)
        
        states[id] = "X";
        cout << "stanje filozofa: " << id << ": ";
        for (int i = 0; i < states.size(); i++)
        {
            cout << states[i] << " ";
        }
        cout << endl;
        
        
        this_thread::sleep_for(chrono::seconds(1));


	// zavrsava jelo i otkljucava vilice da bi mogli drugi filozofi koristiti
        forks[id].unlock();
        forks[(id+1) % states.size()].unlock();
        count++;
    }
}

int main(int argc, char* argv[])
{
   
    MPI::Init(argc, argv);

    int rank, size;
    
    rank = MPI::COMM_WORLD.Get_rank();
    size = MPI::COMM_WORLD.Get_size();



    // Dinamicko dodjeljivanje mutex objekata za vilice
    unique_ptr<mutex[]> forks(new mutex[size]);
    
    // inicjalizacija ostalih stanja na 0
    vector<string> states(size, "0");
     
    //Stvara vektor za pohranu niti
    vector<thread> threads;

   // nova nit za svakog filozofa
    for (int i = rank; i < size; i += size)
    {
        threads.push_back(thread(philosopher, i, ref(forks), ref(states)));
    }

    // cekanje da se sve niti zavrse
    for (auto& t : threads) 
    {
        t.join();
    }

    
    MPI::Finalize();
    return 0;
}
