/*
Napišite program u kojem će svi procesi generirati jedan
nasumičan broj, nakon čega će jedan od procesa načiniti
aritmetičku sumu brojeva svih procesa koristeći operaciju
redukcije, te će dobivenu aritmetičku srednju vrijednost poslati
svim ostalim procesima. Procesi će nakon toga izračunati
odstupanje u postocima u odnosu na dobivenu srednju vrijednost.
Koristite isključivo kolektivnu komunikaciju. Program napisati
korištenjem C++ funkcija.
*/

#include <iostream>
#include <mpi.h>
#include <stdio.h>
#include <cstdlib> //rad s brojevima()
#include <time.h>  
using namespace std;

int main(int argc, char* argv[]) {

    int i, rank, index;
    time_t t;

    int size;
    int suma = 0;
    MPI::Status status;
    MPI::Init(argc, argv);  

    size = MPI::COMM_WORLD.Get_size();
    rank = MPI::COMM_WORLD.Get_rank(); 

    // Inicijalizacija generiranja nasumicnog broja pomocu srand i time vecih od 0
    srand((unsigned) time(&t + rank*100) + rank*100);
    int broj = rand() % 100;

    
    MPI::COMM_WORLD.Allreduce(&broj, &suma, 1, MPI::INT, MPI::SUM);

    // Ispis srednje vrijednosti ako je proces rank 0
    if(rank==0) cout<<"suma = "<<suma<<", prosjek = "<<(float)suma/size<<endl;
    
    MPI::COMM_WORLD.Barrier();
   
  cout<<"proces "<<rank<<"---> generirani random broj je: "<<broj<<", ima odstupanje od: "<<abs(broj - (float)suma/size)<<", a prosjek je: "<<abs(((broj - (float)suma/size)/((float)suma/size)) * 100)<<" %"<<endl;

MPI::Finalize();        
return 0;
}
